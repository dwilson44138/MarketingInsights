﻿//dotnet add package System.Data.Odbc --version 4.7.0
//dotnet add package Microsoft.Azure.Storage.Common --version 11.1.2
//dotnet add package Microsoft.Azure.Storage.Blob --version 11.1.2
//dotnet add package Microsoft.Azure.Storage.File --version 11.1.2
//dotnet add package Microsoft.Azure.ConfigurationManager --version 4.0.0
//dotnet add package Ssh.net

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using Microsoft.Azure;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using System.Data.Odbc;
using Renci.SshNet;
using Renci.SshNet.Sftp;

namespace AzureBlobs
{
    static class Globals
    {      
        public const string sODBCConnection = "DSN=MarketingInsights; Uid=speedeonadm; Pwd=Sp&&d&0n@dm;";
        public const string sBlobAccessKey = "DefaultEndpointsProtocol=https;AccountName=speedeondatalake;AccountKey=hxlt8t5bjbTGeq+5aWJTDSp8PWONl2p8wHYdJIw5508svGrqBMacg3AlhJN7NrC/IuSJjYAcVm93dZccFRUydg==";
        public const string sAzureVendorSourceDirectory = "staging/vendors";
        public const string sCassInputDirectory = @"C:\internal\CassNcoaAutomation\in\";
        public const string sSFTPStagingDirectory = @"C:\Data\Vendors";
    }

    class Program
    {
        static void Main(string[] args)
        {
            SourceData oSourceData = new SourceData();

            OdbcConnection dbConnLoop = new OdbcConnection(Globals.sODBCConnection);
            dbConnLoop.ConnectionTimeout = 2400;
            dbConnLoop.Open();

            //************************************ SFTP ************************************
            OdbcCommand dbCmdSFTPLoop = dbConnLoop.CreateCommand();
            dbCmdSFTPLoop.CommandTimeout = 2400;
            dbCmdSFTPLoop.CommandText = "sp_retrieve_sftp_connections";
            OdbcDataReader dbReaderSFTPConn = dbCmdSFTPLoop.ExecuteReader();
            var dbSFTPDefinition = new {
                                    sftplocation = dbReaderSFTPConn.GetOrdinal("file_source_location"),
                                    sftpfolder = dbReaderSFTPConn.GetOrdinal("file_source_folder"),
                                    sftplogin = dbReaderSFTPConn.GetOrdinal("file_source_login"),
                                    sftppass = dbReaderSFTPConn.GetOrdinal("file_source_password")
                                 };
            while (dbReaderSFTPConn.Read())
            {
                Console.WriteLine("********* Gather SFTP New File Info (" + dbReaderSFTPConn.GetString(dbSFTPDefinition.sftplocation) + ") *********");
                oSourceData.GatherSourceInfoFromSFTP(dbReaderSFTPConn.GetString(dbSFTPDefinition.sftplocation), dbReaderSFTPConn.GetString(dbSFTPDefinition.sftplogin), dbReaderSFTPConn.GetString(dbSFTPDefinition.sftppass), dbReaderSFTPConn.GetString(dbSFTPDefinition.sftpfolder));
                Console.WriteLine("********* Download SFTP New Files (" + dbReaderSFTPConn.GetString(dbSFTPDefinition.sftplocation) + ") *********");
                oSourceData.StageSourceFilesFromSFTP(dbReaderSFTPConn.GetString(dbSFTPDefinition.sftplocation), dbReaderSFTPConn.GetString(dbSFTPDefinition.sftplogin), dbReaderSFTPConn.GetString(dbSFTPDefinition.sftppass), Globals.sSFTPStagingDirectory, dbReaderSFTPConn.GetString(dbSFTPDefinition.sftpfolder));
                Console.WriteLine("********* Move Files Into Azure Blob Datalake *********");
                oSourceData.UploadSFTPStageToAzureBlob(Globals.sSFTPStagingDirectory, Globals.sAzureVendorSourceDirectory);
            }
            dbReaderSFTPConn.Close();
            dbCmdSFTPLoop.Dispose();


            //******************************* Local Directories ****************************
            OdbcCommand dbCmdLocalLoop = dbConnLoop.CreateCommand();
            dbCmdLocalLoop.CommandTimeout = 2400;
            dbCmdLocalLoop.CommandText = "sp_retrieve_local_connections";
            OdbcDataReader dbReaderLocalConn = dbCmdLocalLoop.ExecuteReader();
            var dbLocalDefinition = new {
                                    filelocation = dbReaderLocalConn.GetOrdinal("file_source_location")
                                 };
            while (dbReaderLocalConn.Read())
            {
                Console.WriteLine("********* Gather New File Info From Azure Directoroes *********");
                oSourceData.GatherSourceInformationFromLocalDirectories(dbReaderLocalConn.GetString(dbLocalDefinition.filelocation));
                Console.WriteLine("********* Transfer New Files From Local Directories to Blob Datalake *********");
                oSourceData.UploadLocalStageToAzureBlob();
                Console.WriteLine("********* Process Downloaded Files Into Warehouse *********");
                oSourceData.MonitorAndProcessStaging();
            }        
        }
    }

    class SourceData
    {
        public void UploadLocalStageToAzureBlob()
        {
            Utilities oTransferFiles = new Utilities();
            Utilities oRunSQL = new Utilities();

            OdbcConnection dbConnMain = new OdbcConnection(Globals.sODBCConnection);
            dbConnMain.ConnectionTimeout = 2400;
            dbConnMain.Open();
            OdbcConnection dbConnMainUpd = new OdbcConnection(Globals.sODBCConnection);
            dbConnMainUpd.ConnectionTimeout = 2400;
            dbConnMainUpd.Open();
            OdbcCommand dbCmdFiles = dbConnMain.CreateCommand();
            dbCmdFiles.CommandTimeout = 2400;
            dbCmdFiles.CommandText = "sp_log_localfile_queue";
            OdbcDataReader dbReaderFiles = dbCmdFiles.ExecuteReader();
            var dbDefinition = new {
                                    filekey = dbReaderFiles.GetOrdinal("logfilesourcek"),
                                    file_location = dbReaderFiles.GetOrdinal("file_source_location"),
                                    filename = dbReaderFiles.GetOrdinal("file_source_name"),
                                    file_size = dbReaderFiles.GetOrdinal("file_source_size"),
                                    file_destination = dbReaderFiles.GetOrdinal("file_source_destination")
                                 };
            while (dbReaderFiles.Read())
            {
                try
                {
                    oTransferFiles.TransferLocalFileToAzureBlob(dbReaderFiles.GetString(dbDefinition.file_location), dbReaderFiles.GetString(dbDefinition.filename), Globals.sAzureVendorSourceDirectory + "/" + dbReaderFiles.GetString(dbDefinition.file_destination));
                    bool bOutput1 = oRunSQL.ModifyDatabase("sp_log_update_file_downloaded_queue '" + dbReaderFiles.GetInt64(dbDefinition.filekey).ToString() + "','1'", dbConnMainUpd);
                }
                catch (Exception e)
                {
                    bool bOutput1 = oRunSQL.ModifyDatabase("sp_log_update_file_downloaded_queue '" + dbReaderFiles.GetInt64(dbDefinition.filekey).ToString() + "','0'", dbConnMainUpd);
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.WriteLine(dbReaderFiles.GetString(dbDefinition.file_location) + @"\" + dbReaderFiles.GetString(dbDefinition.filename));
                }
            }
        }

        public void GatherSourceInformationFromLocalDirectories(string sLocalSourceDirectory)
        {
            Utilities oRunSQL = new Utilities();
            OdbcConnection dbConnMain = new OdbcConnection(Globals.sODBCConnection);
            dbConnMain.ConnectionTimeout = 2400;
            dbConnMain.Open();

            DirectoryInfo diLocalDirectory = new DirectoryInfo(sLocalSourceDirectory);
            foreach(FileInfo file in diLocalDirectory.GetFiles())
            {
                try
                {
                    bool bOutput1 = oRunSQL.ModifyDatabase("sp_log_files_for_download '" + sLocalSourceDirectory + "', 'LOCALDRIVE', '" + file.Name.ToString() + "'," + file.Length.ToString(), dbConnMain);
                }
                catch (Exception e)
                {
                    Console.WriteLine("An exception has been caught " + e.ToString());
                }
            }
        }

        public void UploadSFTPStageToAzureBlob(string sLocalDirectory, string sAzureDirectory)
        {
            //*******************************************************************************************************
            //********* Note : Staging for the SFTP Files Needs to Mimic the Final Azure Datalake Structure *********
            //*******************************************************************************************************
            
            Utilities oTransferFiles = new Utilities();
            DirectoryInfo diLocalDirectory = new DirectoryInfo(sLocalDirectory);
            foreach (DirectoryInfo diDir in diLocalDirectory.GetDirectories())
            {
                foreach(FileInfo fiFile in diDir.GetFiles())
                {
                    try
                    {
                        oTransferFiles.TransferLocalFileToAzureBlob(sLocalDirectory + @"\" + diDir.Name, fiFile.Name, sAzureDirectory + "/" + diDir.Name);
                        oTransferFiles.RemoveLocalFile(sLocalDirectory + @"\" + diDir.Name, fiFile.Name);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    finally
                    {
                        Console.WriteLine(diDir.Name + @"\" + fiFile.Name);
                    }
                }
            }
        }

        public void GatherSourceInfoFromSFTP(string sSFTPHost, string sSFTPUser, string sSFTPPassword, string sSFTPDirectory = "")
        {
            Utilities oRunSQL = new Utilities();
            OdbcConnection dbConnMain = new OdbcConnection(Globals.sODBCConnection);
            dbConnMain.ConnectionTimeout = 2400;
            dbConnMain.Open();
            SftpClient oSFTP = new SftpClient(sSFTPHost, sSFTPUser, sSFTPPassword);
            try
            {
                oSFTP.Connect();

                var files = oSFTP.ListDirectory(sSFTPDirectory);

                foreach (var file in files)
                {
                    Console.WriteLine("\t" + file.Name.ToString());
                    bool bOutput1 = oRunSQL.ModifyDatabase("sp_log_files_for_download '" + sSFTPHost + "', 'SFTP', '" + file.Name.ToString() + "'," + file.Length.ToString(), dbConnMain);
                }
                oSFTP.Disconnect();
            }
            catch (Exception e)
            {
                Console.WriteLine("An exception has been caught " + e.ToString());
            }
        }

        public void StageSourceFilesFromSFTP(string sSFTPHost, string sSFTPUser, string sSFTPPassword, string sLocalDirectory, string sSFTPDirectory = "")
        {
            Utilities oRunSQL = new Utilities();
            OdbcConnection dbConnMain = new OdbcConnection(Globals.sODBCConnection);
            dbConnMain.ConnectionTimeout = 2400;
            dbConnMain.Open();
            OdbcConnection dbConnMainUpd = new OdbcConnection(Globals.sODBCConnection);
            dbConnMainUpd.ConnectionTimeout = 2400;
            dbConnMainUpd.Open();

            OdbcCommand dbCmdFiles = dbConnMain.CreateCommand();
            dbCmdFiles.CommandTimeout = 2400;
            dbCmdFiles.CommandText = "sp_log_list_files_queued_for_download '" + sSFTPHost + "', 'SFTP'";
            OdbcDataReader dbReaderFiles = dbCmdFiles.ExecuteReader();
            var dbDefinition = new {
                                    filekey = dbReaderFiles.GetOrdinal("logfilesourcek"),
                                    filename = dbReaderFiles.GetOrdinal("file_source_name"),
                                    file_size = dbReaderFiles.GetOrdinal("file_source_size"),
                                    file_destination = dbReaderFiles.GetOrdinal("file_source_destination")
                                 };
            SftpClient oSFTP = new SftpClient(sSFTPHost, sSFTPUser, sSFTPPassword);
            try
            {
                oSFTP.Connect();

                while (dbReaderFiles.Read())
                {
                    string sFileName = dbReaderFiles.GetString(dbDefinition.filename);
                    long lFileSize = dbReaderFiles.GetInt64(dbDefinition.file_size);
                    long lFileKey = dbReaderFiles.GetInt64(dbDefinition.filekey);
                    string sDestination = dbReaderFiles.GetString(dbDefinition.file_destination);
                    Console.WriteLine(sFileName);
                    Stream fileStream = File.OpenWrite(sLocalDirectory + "\\" + sDestination + "\\" + sFileName);
                    oSFTP.DownloadFile(sFileName, fileStream);
                    if(lFileSize == fileStream.Length)
                    {
                        bool bOutput1 = oRunSQL.ModifyDatabase("sp_log_update_file_downloaded_queue '" + lFileKey.ToString() + "','1'", dbConnMainUpd);
                    }
                    else
                    {
                        bool bOutput1 = oRunSQL.ModifyDatabase("sp_log_update_file_downloaded_queue '" + lFileKey.ToString() + "','0'", dbConnMainUpd);
                    }
                    fileStream.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("An exception has been caught " + e.ToString());
            }
        }

        public void MonitorAndProcessStaging()
        {
            Microsoft.ApplicationInsights.Extensibility.Implementation.TelemetryDebugWriter.IsTracingDisabled = true;
            OdbcConnection dbConnMain = new OdbcConnection(Globals.sODBCConnection);
            dbConnMain.ConnectionTimeout = 2400;
            dbConnMain.Open();
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(Globals.sBlobAccessKey);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer cbcStaging = blobClient.GetContainerReference("staging");
            CloudBlobContainer cbcArchive = blobClient.GetContainerReference("archive");
            if (cbcStaging.Exists())
            {
                CloudBlobDirectory cbdStagingVendor = cbcStaging.GetDirectoryReference("vendors");
                foreach (IListBlobItem blobitem in cbdStagingVendor.ListBlobs())
                {
                    if (blobitem is CloudBlobDirectory)
                    {
                        CloudBlobDirectory cbdStagingDirectory = (CloudBlobDirectory)blobitem;
                        String[] sDirectoryPath = cbdStagingDirectory.Prefix.Split("/");
                        String sDirectory = sDirectoryPath[sDirectoryPath.Length - 2].ToString();
                        CloudBlobDirectory cbdArchiveDirectory = cbcArchive.GetDirectoryReference(cbdStagingDirectory.Prefix.ToString());
                        bool bFile = true;
                        bool bArchive = true;
                        foreach(IListBlobItem item in cbdStagingDirectory.ListBlobs())
                        {
                            if (item is CloudBlockBlob)
                            {
                                CloudBlockBlob cbbFile = (CloudBlockBlob)item;
                                String[] sFilePath = cbbFile.Name.Split("/");
                                String sFileName = sFilePath[sFilePath.Length - 1].ToString();
                                if(bFile)
                                {
                                    Console.WriteLine("\n" + sDirectory.ToString() + " (" + cbbFile.Properties.Created.ToString() + ")");
                                    bFile = false;
                                    Console.WriteLine("\texec sp_" + sDirectory + " @trigger_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + "'");
                                    OdbcCommand dbCmd1 = new OdbcCommand("exec sp_" + sDirectory + " @trigger_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + "'", dbConnMain);
                                    dbCmd1.CommandTimeout = 40000;
                                    Console.WriteLine("\t\tStart  - " + DateTime.Now);
                                    try 
                                    {
                                        dbCmd1.ExecuteNonQuery();
                                    }
                                    catch(OdbcException e)
                                    {
                                        bArchive = false;
                                        if(e.Message.ToString().Contains("Could not find stored"))
                                        {
                                            Console.WriteLine("\t\tCould Not Find Stored Procedure (sp_" + sDirectory + ")");
                                        }
                                        else
                                        {
                                            Console.WriteLine("\t\tError In Store Procedure" + "\n\n" + e.Errors.ToString());
                                        }
                                    }
                                    catch(Exception e)
                                    {
                                        bArchive = false;
                                        Console.WriteLine("\t\tError In Store Procedure" + "\n\n" + e.ToString());
                                    }
                                    finally
                                    {
                                        dbCmd1 = null;
                                        Console.WriteLine("\t\tEnd    - " + DateTime.Now);
                                        var vCleanse = new CleansingRoutines();
                                        vCleanse.ConsumerCleansing();
                                        var vCN = new CASSNCOA();
                                        vCN.CASSNCOA_Out_File(sDirectory);
                                    }
                                }
                                if (bArchive)
                                {
                                    try
                                    {
                                        CloudBlob blobSource = cbdStagingDirectory.GetBlobReference(sFileName);
                                        CloudBlob blobArchive = cbdArchiveDirectory.GetBlobReference(sFileName);
                                        string result = blobArchive.StartCopy(blobSource.Uri);
                                        CopyState csResult = blobArchive.CopyState;
                                        if (csResult.Status == CopyStatus.Success)
                                        {
                                            blobSource.Delete();
                                        }
                                        Console.WriteLine("\tFile Has Been Archived (" + cbbFile.Name.ToString() + ") - " + DateTime.Now);
                                    }
                                    catch(Exception e)
                                    {
                                        Console.WriteLine("\tError In Archiving" + "\n\n" + e.ToString());
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("\tFile Has Not Been Archived (" + cbbFile.Name.ToString() + ") - " + DateTime.Now);
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    class CASSNCOA 
    {
        public void CASSNCOA_Out_File (string Source_Name)
        {
            OdbcConnection dbConnCASS = new OdbcConnection("DSN=MarketingInsights; Uid=speedeonadm; Pwd=Sp&&d&0n@dm;");
            dbConnCASS.ConnectionTimeout = 2400;
            dbConnCASS.Open();
            OdbcCommand dbCmdCASS = dbConnCASS.CreateCommand();
            dbCmdCASS.CommandTimeout = 2400;
            dbCmdCASS.CommandText = "sp_cass_ncoa_output '" + Source_Name + "'";
            OdbcDataReader dbReaderCASS = dbCmdCASS.ExecuteReader();
            int iRecordCount = 0;
            int iSourceNum = 0;
            StringBuilder sbRecords = new StringBuilder();
            string sSourceName = "";
            var dbDefinition = new {
                                    uniqueid = dbReaderCASS.GetOrdinal("uniqueid"),
                                    first_name = dbReaderCASS.GetOrdinal("first_name"),
                                    last_name = dbReaderCASS.GetOrdinal("last_name"),
                                    address1 = dbReaderCASS.GetOrdinal("address1"),
                                    address2 = dbReaderCASS.GetOrdinal("address2"),
                                    city = dbReaderCASS.GetOrdinal("city"),
                                    state = dbReaderCASS.GetOrdinal("state"),
                                    zip = dbReaderCASS.GetOrdinal("zip"),
                                    zip4 = dbReaderCASS.GetOrdinal("zip4"),
                                    source = dbReaderCASS.GetOrdinal("source"),
                                    content = dbReaderCASS.GetOrdinal("content")
                                 };
            while (dbReaderCASS.Read())
            {
                iRecordCount++;
                if (iRecordCount == 1)
                {   
                    iSourceNum++;
                    sSourceName = dbReaderCASS.GetString(dbDefinition.source) + dbReaderCASS.GetString(dbDefinition.content) + "_" + ("0" + iSourceNum.ToString()).Substring(("0" + iSourceNum.ToString()).Length - 2) + "_" + DateTime.Now.ToString("yyyyMMdd") + ".csv";
                    sbRecords.Append("\"UniqueID\",\"FIRST_NAME\",\"LAST_NAME\",\"ADDRESS1\",\"ADDRESS2\",\"CITY\",\"STATE\",\"ZIP\",\"ZIP4\"\n");
                }
                sbRecords.Append("\"" + dbReaderCASS.GetInt64(dbDefinition.uniqueid).ToString() + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.first_name) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.last_name) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.address1) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.address2) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.city) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.state) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.zip) + "\",");
                sbRecords.Append("\"" + dbReaderCASS.GetString(dbDefinition.zip4) + "\"\n");
                if (iRecordCount == 100000)
                {
                    write_file(Globals.sCassInputDirectory, sSourceName, sbRecords);
                    sbRecords.Clear();
                    iRecordCount = 0;
                }
            }
            if (iRecordCount > 0)
            {
                write_file(Globals.sCassInputDirectory, sSourceName, sbRecords);
            }
        }

        static void write_file (string sDirectory, string sFileName, StringBuilder sbContent)
        {
            StreamWriter swCASSFile = new StreamWriter(sDirectory + sFileName);
            swCASSFile.Write(sbContent);
            swCASSFile.Flush();
            swCASSFile.Close();
        }
    }

    class CleansingRoutines
    {
        public void ConsumerCleansing()
        {
            OdbcConnection dbConnMain = new OdbcConnection(Globals.sODBCConnection);
            dbConnMain.ConnectionTimeout = 2400;
            dbConnMain.Open();
            Utilities oRunSQL = new Utilities();
            bool bOutput1 = oRunSQL.ModifyDatabase("TRUNCATE TABLE lkp_cleanse_consumers", dbConnMain, "Truncate");
            bool bOutput2 = oRunSQL.ModifyDatabase("sp_cleanse_vulgarity", dbConnMain, "Vulgarity");
            bool bOutput3 = oRunSQL.ModifyDatabase("sp_cleanse_numeric", dbConnMain, "Numeric");
            bool bOutput4 = oRunSQL.ModifyDatabase("sp_cleanse_vowels", dbConnMain, "Vowels Check");
            bool bOutput5 = oRunSQL.ModifyDatabase("sp_cleanse_verify_characters", dbConnMain, "Character Check");
            bool bOutput6 = oRunSQL.ModifyDatabase("sp_cleanse_invalid_spacing", dbConnMain, "Spacing Issues");
            bool bOutput7 = oRunSQL.ModifyDatabase("sp_cleanse_fname_vowels", dbConnMain, "Vowels Check First");
            bool bOutput8 = oRunSQL.ModifyDatabase("sp_cleanse_lname_vowels", dbConnMain, "Vowel Check Last");
            bool bOutput9 = oRunSQL.ModifyDatabase("sp_cleanse_same_lname_fname", dbConnMain, "Same First Last");
            bool bOutput10 = oRunSQL.ModifyDatabase("sp_cleanse_mrmrs", dbConnMain, "Mr Mrs");
            Duplications(dbConnMain);
            bool bOutput11 = oRunSQL.ModifyDatabase("sp_cleanse_update_consumer", dbConnMain, "Apply Validations");
        }

        static void Duplications (OdbcConnection dbConnMain)
        {
            Regex rxDups = new Regex(@"([A-Z])\1{2}", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            Regex rxMultiDups = new Regex(@"([A-Z][A-Z])\1{2}", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            Regex rxUnique = new Regex(@"(.).*?((?!.*?\1).).*?((?!.*?\2).)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            int iCount = 0;
            string sName = "";

            OdbcConnection dbConn = new OdbcConnection(Globals.sODBCConnection);
            dbConn.ConnectionTimeout = 6400;
            dbConn.Open();
            StringBuilder sInsertSQL = new StringBuilder("");

            OdbcCommand dbCmd = new OdbcCommand("SELECT sourceconsumerk, source_consumer_name_full, source_consumer_name_first, source_consumer_name_last FROM dim_source_consumer WHERE flag_validated = 0", dbConn);
            OdbcDataReader dbReader = dbCmd.ExecuteReader();
            while (dbReader.Read())
            {
                sName = rxDups.Matches(dbReader.GetString(2)) + " " + rxDups.Matches(dbReader.GetString(3));
                MatchCollection matchDups = rxDups.Matches(sName);
                if (matchDups.Count > 0)
                {
                    iCount++;
                    sInsertSQL.Append("INSERT INTO lkp_cleanse_consumers VALUES ('04-DUPLICATES', " + dbReader.GetInt64(0).ToString() + ");\n");
                }
                MatchCollection matchMultiDups = rxMultiDups.Matches(dbReader.GetString(1));
                if (matchMultiDups.Count > 0)
                {
                    iCount++;
                    sInsertSQL.Append("INSERT INTO lkp_cleanse_consumers VALUES ('05-REPEATS', " + dbReader.GetInt64(0).ToString() + ");\n");
                }
                int iUnique = (new HashSet<char>(dbReader.GetString(1))).Count;
                if (iUnique <= 4 && dbReader.GetString(1).Length > 5)
                {
                    iCount++;
                    sInsertSQL.Append("INSERT INTO lkp_cleanse_consumers VALUES ('06-UNIQUES', " + dbReader.GetInt64(0).ToString() + ");\n");
                }
                if(iCount > 500)
                {
                    OdbcConnection dbConnPost = new OdbcConnection("DSN=MarketingInsights; Uid=speedeonadm; Pwd=Sp&&d&0n@dm;");
                    dbConnPost.ConnectionTimeout = 6400;
                    dbConnPost.Open();
                    Utilities oRunSQL = new Utilities();
                    bool bOutput1 = oRunSQL.ModifyDatabase(sInsertSQL.ToString(), dbConnPost, "RegEx Validations");
                    iCount = 0;
                }
            }
            if (iCount > 0)
            {

                OdbcConnection dbConnPost = new OdbcConnection("DSN=MarketingInsights; Uid=speedeonadm; Pwd=Sp&&d&0n@dm;");
                dbConnPost.ConnectionTimeout = 6400;
                dbConnPost.Open();
                Utilities oRunSQL = new Utilities();
                bool bOutput1 = oRunSQL.ModifyDatabase(sInsertSQL.ToString(), dbConnPost, "RegEx Validations");
            }
        }
    }

    class Utilities
    {
        public bool ModifyDatabase(string sSQL, OdbcConnection dbConnection, string sOutput = "Ignore")
        {
            if (sOutput != "Ignore")
            {
                Console.WriteLine("\t" + sOutput);
            }
            OdbcCommand dbCmd = new OdbcCommand(sSQL, dbConnection);
            try
            {
                dbCmd.ExecuteNonQuery();
                return true;
            }
            catch (OdbcException e)
            {
                Console.WriteLine("\t" + e.Message);
                return false;
            }
            finally
            {
                dbCmd.Dispose();
            }
        }

        public void TransferLocalFileToAzureBlob(string sDirectory, string sLocalFile, string sAzureDirectory)
        {
            FileStream fsFile = new FileStream(sDirectory + @"\" + sLocalFile, FileMode.Open);
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(Globals.sBlobAccessKey);
                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
                CloudBlobContainer cbcStaging = blobClient.GetContainerReference(sAzureDirectory);
                CloudBlockBlob cbbBlobFile = cbcStaging.GetBlockBlobReference(sLocalFile);
                //cbbBlobFile.Properties.ContentType = fiFile.Extension;
                cbbBlobFile.UploadFromStream(fsFile);
                CopyState csResult = cbbBlobFile.CopyState;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                fsFile.Close();
            }
        }

        public void RemoveLocalFile(string sDirectory, string sLocalFile)
        {
            try
            {
                File.Delete(sDirectory + @"\" + sLocalFile);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }

}
